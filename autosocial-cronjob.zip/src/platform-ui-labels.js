// Localized third-party platform labels used only for browser automation selectors.
const LABELS = {
  create: ["create", "erstellen"],
  instagramPostFormat: ["post", "beitrag"],
  instagramReelFormat: ["reel", "reels"],
  instagramUploadTrigger: ["from computer", "select from computer", "vom computer", "ausw\u00e4hlen"],
  next: ["next", "weiter"],
  captionAttribute: ["caption", "beschreib"],
  share: ["share", "post", "publish", "teilen", "posten"],
  posted: ["shared", "posted", "geteilt", "ver\u00f6ffentlicht", "beitrag wurde geteilt"],
  error: ["error", "failed", "couldn't", "fehler", "nicht m\u00f6glich", "konnte nicht"],

  youtubeCreate: ["create", "erstellen"],
  youtubeUploadVideo: ["upload videos", "upload video", "videos hochladen", "video hochladen"],
  youtubeSelectFiles: ["select files", "dateien ausw\u00e4hlen"],
  youtubeTitleAttribute: ["title", "titel"],
  youtubeDescriptionAttribute: ["description", "beschreibung"],
  youtubeNotMadeForKids: [
    "not made for kids",
    "nicht fur kinder",
    "nicht f\u00fcr kinder",
    "nicht speziell fur kinder",
    "nicht speziell f\u00fcr kinder",
  ],
  youtubePublic: ["public", "\u00f6ffentlich"],
  youtubePublish: ["publish", "ver\u00f6ffentlichen"],
  youtubeSave: ["save", "speichern"],
  youtubePublished: ["published", "ver\u00f6ffentlicht"],
  youtubeProcessing: ["processing", "verarbeitet"],

  tiktokSearchSounds: ["Search sounds", "Sounds suchen"],
  tiktokEdit: ["edit", "bearbeiten"],
  tiktokSounds: ["sound", "sounds", "audio"],
  tiktokText: ["text"],
  tiktokSave: ["Save", "Speichern"],
  tiktokCancel: ["Cancel", "Abbrechen"],
  tiktokShortContentCheck: ["short content check", "kurze inhaltsprufung", "kurze inhaltspr\u00fcfung"],
  tiktokEnable: ["enable", "turn on", "allow", "ok", "einschalten", "aktivieren"],
  tiktokContinue: ["got it", "continue", "verstanden", "weiter", "fortfahren"],
  tiktokLater: ["later", "not now", "skip", "spater", "spaeter", "sp\u00e4ter"],
  tiktokClose: ["cancel", "close", "abbrechen", "schliessen", "schlie\u00dfen"],
  tiktokPublish: ["publish", "post", "ver\u00f6ffentlichen", "veroeffentlichen", "publicar", "publier", "pubblica"],
  tiktokPublished: [
    "published",
    "posted",
    "scheduled",
    "ver\u00f6ffentlicht",
    "veroeffentlicht",
    "erfolgreich",
    "geplant",
    "zur prufung eingereicht",
    "zur pr\u00fcfung eingereicht",
  ],
  tiktokFailed: [
    "failed",
    "error",
    "could not",
    "retry",
    "nicht moglich",
    "nicht m\u00f6glich",
    "fehlgeschlagen",
    "erneut versuchen",
  ],
  tiktokConfirm: [
    "publish",
    "post",
    "confirm",
    "continue",
    "ver\u00f6ffentlichen",
    "veroeffentlichen",
    "best\u00e4tigen",
    "bestaetigen",
    "fortfahren",
  ],
};

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function terms(...keys) {
  return keys.flatMap((key) => LABELS[key] || []);
}

function pattern(...keys) {
  const values = terms(...keys);
  if (values.length === 0) {
    throw new Error(`No platform UI labels configured for: ${keys.join(", ")}`);
  }
  return new RegExp(values.map(escapeRegExp).join("|"), "i");
}

function textSelector(selector, ...keys) {
  return terms(...keys)
    .map((value) => `${selector}:has-text("${value.replace(/"/g, '\\"')}")`)
    .join(", ");
}

function attrSelector(selector, attr, ...keys) {
  return terms(...keys)
    .map((value) => `${selector}[${attr}*="${value.replace(/"/g, '\\"')}" i]`)
    .join(", ");
}

module.exports = {
  attrSelector,
  pattern,
  terms,
  textSelector,
};
